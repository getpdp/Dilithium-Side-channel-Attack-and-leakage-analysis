#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "randombytes.h"
#include "sign.h"
#include "hal.h"
#include "simpleserial.h"

#define MLEN 33
#define NTESTS 1

  //这是官方的消息用来验证
  //uint8_t m[MLEN] = {0xD8,0x1C,0x4D,0x8D,0x73,0x4F,0xCB,0xFB,0xEA,0xDE,0x3D,0x3F,0x8A,0x03,0x9F,0xAA,0x2A,0x2C,0x99,0x57,0xE8,0x35,0xAD,0x55,0xB2,0x2E,0x75,0xBF,0x57,0xBB,0x55,0x6A,0xC8};
  //uint8_t m[MLEN] = {0};
  uint8_t m[MLEN] = {0xb4,0x66,0x3a,0x7a,0x98,0x83,0x38,0x6a,0x2a,0xe4,0xcb,0xd9,0x37,0x87,0xe2,0x47,0xbf,0x26,0x08,0x7e,0x38,0x26,0xd1,0xb8,0xdb,0xeb,0x67,0x9e,0x49,0xc0,0xbb,0x28,0x6e};
  uint8_t sm[MLEN + CRYPTO_BYTES]; //签名后的 2420 + MLEN = 2453
  uint8_t m2[MLEN + CRYPTO_BYTES];
  uint8_t pk[CRYPTO_PUBLICKEYBYTES];//1312 = 5* 255+37
  uint8_t sk[CRYPTO_SECRETKEYBYTES];//2544
  //这是官方的seed用来验证
  //uint8_t SEED[SEEDBYTES]={0x7c,0x99,0x35,0xa0,0xb0,0x76,0x94,0xaa,0x0c,0x6d,0x10,0xe4,0xdb,0x6b,0x1a,0xdd,0x2f,0xd8,0x1a,0x25,0xcc,0xb1,0x48,0x03,0x2d,0xcd,0x73,0x99,0x36,0x73,0x7f,0x2d};  //32

  //这是batch0的seed
  //uint8_t SEED[SEEDBYTES]={0x7c,0x48,0x52,0x58,0x86,0x74,0x50,0x66,0x1a,0x3e,0xeb,0xfe,0xca,0x2,0x43,0x48,0x70,0x21,0x29,0x7,0xc7,0x50,0x28,0x1b,0xf7,0xdc,0x36,0xac,0x48,0xe6,0x67,0x82};
  uint8_t SEED[SEEDBYTES] = {0x06,0x10,0x67,0x8f,0xf4,0xdc,0x31,0x28,0xe1,0x61,0x9f,0x91,0x5d,0xc1,0x92,0xc2,0x20,0xf8,0xfa,0xd9,0x4d,0xa1,0x94,0x3b,0x90,0xaa,0xec,0x40,0x16,0x83,0xa4,0x92};
uint8_t recv_0(uint8_t* data, uint8_t dlen)
{
  simpleserial_put('1', 255, sm+255*0);
  return 0;
}
uint8_t recv_1(uint8_t* data, uint8_t dlen)
{
  simpleserial_put('2', 255, sm+255*1);
  return 0;
}

uint8_t recv_2(uint8_t* data, uint8_t dlen)
{
  simpleserial_put('3', 255, sm+255*2);
  return 0;
}

uint8_t recv_3(uint8_t* data, uint8_t dlen)
{
  simpleserial_put('4', 255, sm+255*3);
  return 0;
}

uint8_t recv_4(uint8_t* data, uint8_t dlen)
{
  simpleserial_put('5', 255, sm+255*4);
  return 0;
}

uint8_t recv_5(uint8_t* data, uint8_t dlen)
{
  simpleserial_put('6', 255, sm+255*5);
  return 0;
}

uint8_t recv_6(uint8_t* data, uint8_t dlen)
{
  simpleserial_put('7', 255, sm+255*6);
  return 0;
}

uint8_t recv_7(uint8_t* data, uint8_t dlen)
{
  simpleserial_put('8', 255, sm+255*7);
  return 0;
}
uint8_t recv_8(uint8_t* data, uint8_t dlen)
{
  simpleserial_put('9', 255, sm+255*8);
  return 0;
}

uint8_t recv_9(uint8_t* data, uint8_t dlen)
{
  simpleserial_put('!', 158, sm+255*9);
  return 0;
}


//////////////////////////////

  
uint8_t main_func(uint8_t* data, uint8_t dlen)
{
  unsigned int i, j;
  int ret;
  size_t mlen, smlen;
  
  for(i = 0; i < NTESTS; ++i) {
    //randombytes(m, MLEN); 随机数
    //memcpy(m, data, MLEN);
    //memcpy(SEED, data+MLEN, SEEDBYTES);
    crypto_sign_keypair(pk, sk, SEED);

    //trigger_high();
    crypto_sign(sm, &smlen, m, MLEN, sk);
    //trigger_low();
    ret = crypto_sign_open(m2, &mlen, sm, smlen, pk);

    // if(ret) {
    //   fprintf(stderr, "Verification failed\n");
    //   return -1;
    // }

    // if(mlen != MLEN) {
    //   fprintf(stderr, "Message lengths don't match\n");
    //   return -1;
    // }

    // for(j = 0; j < mlen; ++j) {
    //   if(m[j] != m2[j]) {
    //     fprintf(stderr, "Messages don't match\n");
    //     return -1;
    //   }
    // }

  //   randombytes((uint8_t *)&j, sizeof(j));
  //   do {
  //     randombytes(m2, 1);
  //   } while(!m2[0]);
  //   sm[j % CRYPTO_BYTES] += m2[0];
  //   ret = crypto_sign_open(m2, &mlen, sm, smlen, pk);
  //   if(!ret) {
  //     fprintf(stderr, "Trivial forgeries possible\n");
  //     return -1;
  //   }
  }

  // printf("CRYPTO_PUBLICKEYBYTES = %d\n", CRYPTO_PUBLICKEYBYTES);
  // printf("CRYPTO_SECRETKEYBYTES = %d\n", CRYPTO_SECRETKEYBYTES);
  // printf("CRYPTO_BYTES = %d\n", CRYPTO_BYTES);

  	simpleserial_put('*', 4, (uint8_t*)&ret);// 这个没有问题
    
  return 0;
}


int main(void)
{	
	platform_init();
	init_uart();
	trigger_setup();	
	simpleserial_init();
  
  //59 + 32 = 91
	simpleserial_addcmd('z', 33, main_func);
  simpleserial_addcmd('a', 1, recv_0);
  simpleserial_addcmd('b', 1, recv_1);
  simpleserial_addcmd('c', 1, recv_2);
  simpleserial_addcmd('d', 1, recv_3);
  simpleserial_addcmd('e', 1, recv_4);
  simpleserial_addcmd('f', 1, recv_5);
  simpleserial_addcmd('g', 1, recv_6);
  simpleserial_addcmd('h', 1, recv_7);
  simpleserial_addcmd('i', 1, recv_8);
  simpleserial_addcmd('j', 1, recv_9);



//  uint8_t data[2] = {1,0};
// 	test(data);
	while(1)
		simpleserial_get();
  	return 0;
}